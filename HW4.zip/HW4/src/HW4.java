import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
/**
 * CS2 HW4
 * HW4.java
 * Purpose: Imports text file into string array, sorts array using two methods of sorting, compares time of sorting
 * 
 * @author grantschumacher
 * @version 1.0 9/22/17
 */
public class HW4 {
	
	double finalBubbleClockTime;
	long finalBubbleCPUTime;
	double finalInternalClockTime;
	long finalInternalCPUTime;
	
	public static void main(String[] args) {
		HW4 h = new HW4();
		ArrayList<String> originalList = new ArrayList<String>();
		ArrayList<String> duplicateList = new ArrayList<String>();
		Scanner sc = new Scanner(System.in);
		System.out.println("Welcome, please enter the name of the file you wish to sort:");
		System.out.print("Filename: ");
		originalList = h.readFile(sc.nextLine());
		duplicateList = originalList;
		sc.close();
		System.out.println("Word count: " + originalList.size());
		System.out.println("-------------------------Sorting-------------------------------");
		h.bubbleSort(originalList);
		h.internalSort(duplicateList);
		h.printTimes();
		
	}
	
	/**
	 * Prints the amount of time elapsed for both sorting methods
	 */
	public void printTimes(){
		System.out.println("Wall Clock:");
		System.out.println("   --Bubble Sort: " + finalBubbleClockTime + " Milliseconds");
		System.out.println("   --Internal Sort: " + finalInternalClockTime + " Milliseconds");
		System.out.println("CPU time:");
		System.out.println("   --Bubble Sort: " + finalBubbleCPUTime + " Nano Seconds");
		System.out.println("   --Internal Sort: " + finalInternalCPUTime + " Nano Seconds");
	}
	
	/**
	 * Uses the internal sort to sort an array list passed in.
	 * @param words
	 */
	public void internalSort(ArrayList<String> words){
		double startClockTime;
		double endClockTime;
		long startCPUTime;
		long endCPUTime;
		startClockTime = System.currentTimeMillis();
		startCPUTime = System.nanoTime();
		Collections.sort(words);
		endClockTime = System.currentTimeMillis();
		endCPUTime = System.nanoTime();
		finalInternalClockTime = endClockTime - startClockTime;
		finalInternalCPUTime = endCPUTime - startCPUTime;
	}
	
	/**
	 * Reads in a specified file and converts it into a string array list with each index being one word from the file, excludes special characters
	 * @param fileName
	 * @return
	 */
	public ArrayList<String> readFile(String fileName) {
		String word;
		ArrayList<String> fileLine = new ArrayList<String>();

		try {
			File file = new File(fileName);
			Scanner inputFile = new Scanner(file);

			while (inputFile.hasNext()) {
				word = inputFile.next();
				word = word.replaceAll("[^a-zA-Z0-9]","");
				fileLine.add(word);
			}

			inputFile.close();

		} catch (Exception ex) {
			System.out.println(ex);
		}
		return fileLine;
	}
	/**
	 * Sorts array using bubble sort 
	 * @param words
	 * @return
	 */
	public ArrayList<String> bubbleSort(ArrayList<String> words){
		String temp;
		boolean sorting = true;
		
		double startClockTime;
		double endClockTime;
		long startCPUTime;
		long endCPUTime;
		
		startClockTime  = System.currentTimeMillis(); //Start timer
		startCPUTime = System.nanoTime();
		while(sorting){ //Run Bubble Sort
			sorting = false;
			for(int i = 0; i < words.size() - 1; i++){
				if(words.get(i).compareTo(words.get(i + 1)) > 0){
					temp = words.get(i);
					words.set(i, words.get(i+1));
					words.set(i+1, temp);
					sorting = true;
				}
			}
		}
		endClockTime = System.currentTimeMillis();
		endCPUTime = System.nanoTime();
		finalBubbleClockTime = endClockTime - startClockTime;
		finalBubbleCPUTime = endCPUTime - startCPUTime;
		
		return words;
	}
	
	
}
